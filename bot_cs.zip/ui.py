from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def get_main_menu_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [InlineKeyboardButton("🎲 Играть", callback_data="play")],
        [
            InlineKeyboardButton("💰 Баланс", callback_data="balance"),
            InlineKeyboardButton("📜 Правила", callback_data="rules")
        ],
        [
            InlineKeyboardButton("🏆 Топ игроков", callback_data="top"),
            InlineKeyboardButton("👤 Мой ник", callback_data="set_nickname")
        ],
        [
            InlineKeyboardButton("Пополнить баланс 💳", callback_data="deposit"),
            InlineKeyboardButton("📤 Вывод средств", callback_data="withdraw")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_back_to_menu_keyboard_simple() -> InlineKeyboardMarkup:
    keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data="back_to_start")]]
    return InlineKeyboardMarkup(keyboard)

def get_back_to_menu_keyboard_nested() -> InlineKeyboardMarkup:
    keyboard = [[InlineKeyboardButton("⬅️ Назад в меню", callback_data="main_menu_from_nested")]]
    return InlineKeyboardMarkup(keyboard)

def get_game_choice_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton("🎲", callback_data="game_dice"),
            InlineKeyboardButton("🏀", callback_data="game_basketball"),
            InlineKeyboardButton("⚽", callback_data="game_football"),
            InlineKeyboardButton("🎰", callback_data="game_dart"),
        ],
        [InlineKeyboardButton("⬅️ Назад в меню", callback_data="main_menu_from_nested")]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_deposit_options_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton("15⭐", callback_data="deposit_15"),
            InlineKeyboardButton("25 ⭐", callback_data="deposit_25"),
            InlineKeyboardButton("50 ⭐", callback_data="deposit_50"),
        ],
        [InlineKeyboardButton("⬅️ Назад в меню", callback_data="main_menu_from_nested")]
    ]
    return InlineKeyboardMarkup(keyboard)